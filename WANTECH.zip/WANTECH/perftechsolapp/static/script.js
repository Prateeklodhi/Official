
AOS.init();//Animation on Scroll

$(document).ready(function() {
  $(window).scroll(function() {
    if ($(document).scrollTop() > 100) {
      $(".navbar").addClass("scroll-nav");
    } else {
      $(".navbar").removeClass("scroll-nav");
    }
  });
});
function navbar()
{
    if($('.menu').hasClass("activemenu")==false)
    {
        
        // $(".hamburger").click(function(){ 
            $('.navbar').addClass("activenavbar");
            $('.menu').addClass("activemenu");
            // $(".menu-icon").addClass("iconactive");
            $(".address_menu ").addClass("active");
            $(".map__menu__inner ").addClass("active");                    
            $(".logo").addClass("activelogo");
            $(".menues").addClass("active");
        // }); 
        
    }
    else
    {
        $('.menu').removeClass("activemenu");
        $('.navbar').removeClass("activenavbar");
        // $(".menu-icon").removeClass("iconactive");
        $(".logo").removeClass("activelogo");
        $(".menues").removeClass('active');
        $(".address_menu").removeClass("active");
        $(".map__menu__inner ").removeClass("active");
    
    }
}
